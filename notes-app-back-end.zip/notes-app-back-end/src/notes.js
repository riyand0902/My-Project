const notes = [];
 
module.exports = notes;